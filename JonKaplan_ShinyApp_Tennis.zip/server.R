
#install.packages('ggthemes')

shinyServer(function(input, output){
  
  
  output$winPercentage <- renderInfoBox({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    #tennis2 = filterTennisDate(tennis, input$dateRange[1],input$dateRange[2])
    wp = generateAllWinPercent(tennis2,input$player)
    infoBox(title = 'Win Percentage (filters applied):',value = paste(round(wp,4)*100,'%') , color= 'blue' ,icon = icon("percent"))
  })
  
  output$country <- renderGvis({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    
    countryStatsWinner = tennis2 %>% group_by(winner_ioc) %>%
                                    summarise(wins=n(), tourneyWins = sum(round =='F')) %>%
                                    select(country =winner_ioc, Wins = wins, TournamentWins = tourneyWins)
    
    countryStatsLoser = tennis2 %>% group_by(loser_ioc) %>%
                                  summarise(losses=n()) %>%
                                  select(country = loser_ioc, Losses =losses)
    
    playerRep = tennis2 %>% group_by(loser_name) %>%
                summarize(country = first(loser_ioc)) %>%
                group_by(country) %>%
                summarize(playerRep = n()) %>%
                mutate(playerRep=playerRep/sum(playerRep))
    
   
    countryStats = full_join(countryStatsLoser,countryStatsWinner, by ='country')
    countryStats = full_join(countryStats,playerRep, by ='country')
    countryStats[is.na(countryStats)] <- 0
    countryStats$Matches = countryStats$Wins + countryStats$Losses
    #countryStats <- countryStats[c("country", "Wins", "Losses","TournamentWins","Matches")]
    countryStats = countryStats %>% filter(Wins > mean(countryStats$Wins)) %>% 
                                    filter(playerRep >.01)
    
    Bubble <- gvisBubbleChart(countryStats, 
                              idvar="country", 
                              xvar="playerRep", 
                              yvar="TournamentWins",
                              options=list(legend='none',
                                            width = "automatic",
                                            height="600px",
                                            vAxes= "[{title:'Number of Tournament Wins',minValue: -.01}]",
                                            hAxes= "[{title:'Player Representaton',minValue: 0,  maxSize: 1}]"
                                            #sizeAxis = '{minValue: -1,  maxSize: 2}'
                                          )
                           )
  })
  
  #output$majors  <- renderTable({
  output$majors  <- DT::renderDataTable({
    marker  = rev(unlist(list(color = brewer.pal(8, 'RdYlGn'))))
    marker[9]= c('grey')
    datatable(generatePlayerSlams(tennis,input$player),rownames=FALSE) %>%
      formatStyle(names(generatePlayerSlams(tennis,input$player))[-1],
                  backgroundColor = styleEqual(c('Champ','F',"SF","QF","R16","R32","R64","R128",'DNP'), 
                                               marker))
  })
  
  output$legend  <- renderTable({roundNames}) 
  
  
  
  
  output$numWins <- renderInfoBox({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    np = generateTotalMatches(tennis2,input$player)
    wp = generateAllWinPercent(tennis2,input$player)
    tw = generateNumberOfTourneyWinsPlayerList(tennis2,input$player)
    infoBox(title = 'Matches/Wins/Tourney Wins (filters applied):',value =paste(np,'/',np*wp,'/',tw),color= 'aqua',icon= icon("plus"))
  })
  
  output$bestFinish <- renderInfoBox({
    infoBox(title = 'Country',value = returnPlayerCountry(tennis,input$player),color= 'green', icon = icon("globe"))
  })
  
  output$value <- renderText({input$surfaces})
  output$value <- renderText({input$toruney})
  
  output$tableTennis <- DT::renderDataTable({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    indiv_df = individualStats(tennis2, player)
    comp_df = h2h(tennis2, input$player, player)
    topPlayers = left_join(indiv_df,comp_df, by='Player')
    topPlayers[is.na(topPlayers)] <- 0
    topPlayers = topPlayers %>% arrange(desc(HeadtoHead_Matches))
        
    datatable(topPlayers, rownames=FALSE, height=900) #%>% 
        #formatStyle(input$selected, background="skyblue", fontWeight='bold')
    }) 
  
  output$chiTable <- renderGvis({
    tennisFiltered = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    t= generateChiTable(tennisFiltered,input$player) #rawplayer for all players
    gvisTable(t[[1]],options=list(width = "400px",
                                  height="400px")
              )
  })

  output$chiTest <- renderText({
    tennisFiltered = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    t= generateChiTable(tennisFiltered,input$player)
    chi = t[[2]]
    outcome = ifelse(chi$p.value<.05,
                     'We can reject our null hypothesis that winning is independent from playing surface for this player',
                     'We cannot reject our null hypothesis')
    paste('P-Value:',chi$p.value,outcome,sep="\n")
  })
  
  output$spTable <- renderGvis({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    tennisFiltered = filterRet(tennis2)
    t= generateSimpsonPardoxDataTable(tennisFiltered,player) #rawplayer for all players
    gvisTable(t,options=list(width = "100%",
                             height="575px")
              )
    #datatable(t,rownames=FALSE, height=600)
  })

  output$sp <- renderPlot({
    tennis2 = filterAll(tennis, input$dateRange[1],input$dateRange[2],input$surface,input$toruney)
    tennisFiltered = filterRet(tennis2)
 
    p =ggplot(tennisFiltered,aes(x=loser_points, y=winner_points)) +
        geom_point() +
        geom_abline(intercept = 0,slope =1, color ='red', size=1) +
        #geom_abline(intercept = 0, slope = 1, color='red')
        labs(x= 'Loser Points Scored', y= 'Winner Points Scored',title ='')  
    p
    })
})


#infoBox(title= 'Grand Slam Results (last 4 played in range):', value= tags$p((HTML(paste("Australian:",'value1'),paste(":French:",'value2',br()),paste('Wimbledon:','value3'),paste(":US Open:",'value4'))),style = "font-size: 100%;"),color= 'aqua',icon= icon("tennis-ball"))