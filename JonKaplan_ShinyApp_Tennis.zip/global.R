library(dplyr)
library(ggplot2)
library(tidyverse)
library(tidyr)
library(rsconnect)
library(DT)
library(data.table)
library(shiny)
library(shinydashboard)
library(plotly)
library(RColorBrewer)
library(googleVis)
library(ggthemes)

#setwd('/Users/jkaplan/Desktop/NYCDSA/week1/Shiny/shinyApps/Tennis')
#Read Tennis Data in and make the the tornament dates as.Date()
tennis <- read.csv('./AllTennis_clean.csv',   stringsAsFactors =FALSE)
tennis <- tennis %>% mutate(winner_points = w_1stWon +	w_2ndWon+ (l_svpt -	l_1stWon -	l_2ndWon), 
                            loser_points = w_svpt + l_svpt -winner_points, 
                            SimpsonParadox = loser_points > winner_points)
                              
tennis = mutate(tennis, tourney_date = as.Date(paste(substr(tourney_date, 0, 4),"-",substr(tourney_date, 5, 6),"-",substr(tourney_date, 7, 8),sep=""),format='%Y-%m-%d'))
tennis = mutate(tennis, year = year(tourney_date))

#
grandslams = c("Australian Open","Roland Garros","Us Open","Wimbledon")
surfaces = c('Carpet', 'Clay', 'Grass','Hard')
tourneyLevelPreset = c('Grand Slam', 'Finals', 'Masters', 'Tour Series','Davis Cup','Challenger')
tourneyLevel = c('G', 'F', 'M', 'A','D', 'C')
round = c('Champ','F',"SF","QF","R16","R32","R64","R128","DNP")
roundsPresent = c('Champion','Finals','Semi-Finals','Quarter-Finals','Round of 16', 'Round of 32','Round of 64','Round of 128','Did not play')
roundNames = data.frame(round,roundsPresent)
names(roundNames) <- c('Abbreviations','Round Eliminated')

tennis  <- arrange(tennis, tourney_date)

rawplayer <- sort(unique(union(tennis$winner_name,tennis$loser_name)))

filterTennisDate <- function(tennis,startDate,endDate){
  tennis = tennis %>% filter(tourney_date >= startDate & tourney_date <= endDate)
  return(tennis)
}

filterSurface <- function(tennis,surfaces){
  tennis = tennis %>% filter(surface %in% surfaces)
  return(tennis)
}

filterToruneyLevel <- function(tennis,tourneyLevel){
  tennis = tennis %>% filter(tourney_level %in% tourneyLevel)
  return(tennis)
}


filterAll <-function(tennis= tennis, startDate=minDate,endDate=maxDate, surfaces =surfaces, tourneyLevel=tourneyLevel){
  tennis = filterToruneyLevel(filterSurface(filterTennisDate(tennis, startDate, endDate),surfaces),tourneyLevel)
  return(tennis)
}


generateSimpsonPardoxDataTable <- function(tennis, playerList){
  matches= c()
  wins =c()
  losses = c()
  percentages= c()
  for(i in 1:length(playerList)){
    temp = playerList[i]
    playerWins = nrow(tennis %>% filter(SimpsonParadox == 1) %>%
                                  filter(winner_name == temp))
    playerLosses = nrow(tennis %>% filter(SimpsonParadox == 1) %>%
                                    filter(loser_name == temp))
    playerMatches = playerWins + playerLosses 
    wins = c(wins,playerWins)
    losses = c(losses,playerLosses)
    matches = c(matches, playerMatches)
    percentages= c(percentages, playerWins/playerMatches)
  }
  Player = playerList
  sp = data.frame(Player,matches,wins,losses,percentages)
  colnames(sp) <-  c('Player','Simpson Matches Played','Simpson Wins','Simpson Losses','Win Percentage')
  sp = sp %>% filter(matches>0)
  return(sp)
}

generateNumberOfTourneyWinsPlayerList <- function(tennis,playerList){
  tourneyWins = c()
  for(i in 1:length(playerList)){
    temp = playerList[i]
    temp = nrow(tennis %>% filter(winner_name == temp & round =='F'))
    tourneyWins = c(tourneyWins,temp)
  }
  return(tourneyWins)
}

filterRet <-function(tennis){
  tennisFiltered <- tennis %>% filter(!grepl("RET",score)) %>%
                              filter(!grepl("Play",score)) %>%
                              filter(!grepl("abandoned",score)) %>%
                              filter(!grepl("6-Feb",score)) %>%
                              filter(!grepl("2-Jun",score)) %>%
                              filter(!grepl("Apr-00",score)) %>%
                              filter(!grepl("3-Jun",score)) %>%
                              filter(!grepl("1-Apr",score)) %>%
                              filter(!grepl("3-Feb",score)) %>%
                              filter(!grepl("0-0 0-0",score)) %>%
                              filter(!grepl("NA",score)) %>%
                              filter(!grepl("W/O",score)) %>%
                              filter(!grepl("In Progress",score))
                          
  tennisFiltered = tennisFiltered[!is.na(tennisFiltered$score),]
  tennisFiltered <- filter(tennisFiltered, winner_points>40)
  return(tennisFiltered)
}

generateAllWinPercent <- function(tennis,playerList){
  winPercentage=c()
  for(i in 1:length(playerList)){
        temp = playerList[i]
        totalmatches = sum(tennis$loser_name == temp)+sum(tennis$winner_name == temp)
        winPercentage =c(winPercentage,as.numeric(sum(tennis$winner_name == temp)/(totalmatches)))
  }
  return(winPercentage)
}

generateTotalMatches <- function(tennis,playerList){
  matches=c()
  for(i in 1:length(playerList)){
    temp = playerList[i]
    totalmatches = sum(tennis$loser_name == temp)+sum(tennis$winner_name == temp)
    matches = c(matches,totalmatches)
  }
  return(matches)
}

generateAllTourneyWins <- function(tennis,playerList){
  winner = tennis %>% filter(winner_name %in% playerList & round =='F') %>%
                      group_by(winner_name) %>%
                      summarize(wins=n())
  
  winner = select(winner,c(Player = winner_name,wins)) #can select more stats too
  return(winner)
}

returnPlayerCountry <-function(tennis, player){
  winner = tennis %>% filter(winner_name == player) %>%
                      select(player =winner_name, country =winner_ioc )
  loser = tennis %>% filter(loser_name == player) %>%
                    select(player =loser_name, country =loser_ioc )
  return(distinct(rbind(winner,loser))[,2])
}

individualStats <- function(tennis,playerList){
  Matches= c()
  Wins =c()
  Losses = c()
  WinPercentage= c()
  for(i in 1:length(playerList)){
    temp = playerList[i]
    win = sum(tennis$winner_name == temp)
    total = sum(tennis$loser_name == temp)+sum(tennis$winner_name == temp)
    loss = total - win
    Wins = c(Wins, win)
    Losses = c(Losses,loss)
    Matches = c(Matches, total)
    WinPercentage = c(WinPercentage, paste(round(100*win/total, 2), "%", sep=""))
  }
  Player = playerList
  return(data.frame(Player,Matches, Wins, Losses, WinPercentage))
}

h2h <- function(tennis,player1,playerList){
  h2h_matches= c()
  h2h_wins =c()
  h2h_losses = c()
  h2h_winpercentage= c()
  for(i in 1:length(playerList)){
    temp = playerList[i]
    p1 = tennis %>% filter(winner_name == player1 & loser_name == temp)
    p2 = tennis %>% filter(winner_name == temp & loser_name == player1)
    win = nrow(p1)
    total =nrow(p1)+nrow(p2)
    loss = total - win
    h2h = rbind(p1,p2)
    h2h_wins = c(h2h_wins, win)
    h2h_losses = c(h2h_losses,loss)
    h2h_matches = c(h2h_matches, total)
    percent = ifelse(total ==0,0,win/total)
    h2h_winpercentage= c(h2h_winpercentage, paste(round(100*percent, 2), "%", sep=""))
  }
  Player = playerList
  HeadtoHead_Matches = h2h_matches
  H2H_SelectedPlayer_Wins = h2h_wins
  H2H_SelectedPlayer_Losses = h2h_losses
  H2H_SelectedPlayer_WinPercentage = h2h_winpercentage
  
  return(data.frame(Player,HeadtoHead_Matches, H2H_SelectedPlayer_Wins, H2H_SelectedPlayer_Losses, H2H_SelectedPlayer_WinPercentage))
}

minDate = min(tennis$tourney_date)
maxDate = max(tennis$tourney_date)
days = as.numeric(maxDate-minDate)

minYear = min(year(tennis$tourney_date)) + (ifelse(month(minDate)>1,1,0))
maxYear = max(year(tennis$tourney_date)) - (ifelse(month(maxDate)<10,1,0))

generatePlayerSlams <- function(tennis, selectedPlayer){
  grandslams = c("Australian Open","Roland Garros","US Open","Wimbledon")
  round = c('Champ','F',"SF","QF","R16","R32","R64","R128",'DNP')
  roundsPresent = c('Champion','Finals','Semi-Finals','Quarter-Finals','Round of 16', 'Round of 32','Round of 64','Round of 128','Did not play')
  roundNames = data.frame(round,roundsPresent)
  
  
  grandTennis <- tennis %>% filter(tourney_name %in% grandslams) %>%
    arrange(desc(tourney_date)) %>%
    arrange(desc(match_num)) %>%
    arrange(desc(tourney_name)) %>%
    arrange(desc(year))
  
  winner = grandTennis %>% filter(winner_name==selectedPlayer & round =='F') %>% 
    select(tourney_name,year,round) %>% 
    mutate(round= 'Champ')
  
  loser = data.frame(grandTennis %>% filter(loser_name ==selectedPlayer) %>%
    group_by(tourney_name,year) %>%
    summarise(round=first(round)))
  
  slamsResults = rbind(winner,loser)
  slamsResults = slamsResults %>% filter(year >=minYear) %>% 
                                  filter(year <=maxYear)

  #slamsResults = left_join(slamsResults,roundNames, by='round')
  #slamsResults = mutate(slamsResults, round= roundsPresent)
  #slamsResults = select(slamsResults, c(tourney_name,year,round))
  
  tourneyOrdering <- factor(slamsResults$tourney_name, levels = c("Australian Open","Roland Garros","Wimbledon","US Open"))
  slamsResults = slamsResults[order(tourneyOrdering),]
  #colnames(slamsResults)[1] <- 'Grand Slam Name'
  
  slamsResults = slamsResults %>% spread( year, round, fill = 'DNP', convert = TRUE, drop = TRUE,sep = NULL) %>%
                                  arrange(order(match(tourney_name, slamsResults$tourney_name)))

  colnames(slamsResults)[1] <- 'Grand Slam Name'
  return(slamsResults)
} 

generateChiTable <- function(tennis,selectedPlayer){
  surfaceBreakdown = tennis %>% group_by(surface) %>%
                                summarize(Wins = sum(winner_name == selectedPlayer),
                                          Losses = sum(loser_name == selectedPlayer)) %>%
                                filter(surface %in% surfaces) %>%
                                select(Surface = surface,Wins,Losses)
  
  Tennis_Surface_Breakdown = tennis %>% mutate(win = winner_name == selectedPlayer) %>%
                                mutate(loss = loser_name == selectedPlayer) %>%
                                filter(win|loss ==TRUE) %>%
                                mutate(win = ifelse(win==TRUE,1,0)) %>%
                                select(surface, win)
 
  
  Tennis_Surface_Breakdown = table(Tennis_Surface_Breakdown)
  chi = chisq.test(Tennis_Surface_Breakdown)
  return(list(surfaceBreakdown,chi))
}


matches = generateTotalMatches(tennis,rawplayer)
winPer = generateAllWinPercent(tennis,rawplayer)
playermatches = data.frame(rawplayer,matches,winPer)
s = filter(playermatches, playermatches$matches>(days/10))
s = arrange(s,desc(matches))
player <- s$rawplayer


#How I created combined csv file
#dir = '/Users/jkaplan/Desktop/NYCDSA/week1/Shiny/shinyApps/Data Sets/Tennis'
#files <- list.files(dir, pattern=".csv")
#setwd(dir)
#
#tennis = NULL
#for(i in files){
#  temp <- read.csv(i, header=TRUE,stringsAsFactors =FALSE)
#  tennis = rbind(tennis, temp)
#  total = total + nrow(temp)
#}
#write.csv(tennis, file = "Combined_AllTennis.csv")
