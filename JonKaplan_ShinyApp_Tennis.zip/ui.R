


shinyUI(dashboardPage(skin = "yellow",
    dashboardHeader(title = h2("Tennis Data")),
    dashboardSidebar(
        
        sidebarUserPanel(h4("Tabs and Filters"),
                         image = "https://i1.wp.com/www.healthfitnessrevolution.com/wp-content/uploads/2015/04/ThinkstockPhotos-513920615.jpg"),
        sidebarMenu(
            menuItem("Player Summary", tabName = "top", icon = icon("male")),
            menuItem("Majors", tabName = "majors", icon = icon("cubes")),
            menuItem("Country Stats", tabName = "country", icon = icon("globe")),
            menuItem("Simpsons Paradox", tabName = "sp", icon = icon("question-circle")),
            menuItem("Surface Analysis", tabName = "chi", icon = icon("american-sign-language-interpreting"))
        ),
        selectizeInput("player",
                       "Select Player to Display",
                       player),
        dateRangeInput('dateRange',
                       label = 'Date range input:',
                       start = minDate, 
                       end = maxDate),
        
        checkboxGroupInput('surface',
                           label ='Filter by Surface Type', 
                           choices =surfaces,
                           selected=surfaces), #'initally all selected'
        checkboxGroupInput('toruney',
                           label ='Filter by Tournament Level', 
                           choiceValues = tourneyLevel,
                           choiceNames = tourneyLevelPreset,
                           selected=tourneyLevel) #'initally all selected'

    ),
    dashboardBody(
        tags$head(
            tags$link(rel = "stylesheet", type = "text/css", href = "custom.css")
        ),
        tabItems(
            tabItem(tabName = "top",
                    fluidRow(infoBoxOutput("winPercentage"),
                             infoBoxOutput("numWins"),
                             infoBoxOutput("bestFinish")),
                    fluidRow(box(DT::dataTableOutput("tableTennis"), width = 12,height = 500))),
            tabItem(tabName = "majors",
                    fluidRow(box(title = h1('Major Tournament Finishes'),DT::dataTableOutput("majors"), style = "font-size:110%",width=12)),
                    fluidRow(box(title = 'Legend',tableOutput("legend"),width=3))),
            tabItem(tabName = "country",
                    fluidRow(box(title = h1('Representation by Country'),htmlOutput("country"),width=10, height=800))),
            tabItem(tabName = "chi",
                    fluidRow(box(title = h1("By Surface Chi Squared Tests"),
                                 verbatimTextOutput('chiTest'),width=8),
                             box(htmlOutput("chiTable"),width=4))),
            tabItem(tabName = "sp",
                    fluidRow(box(title = h3("Simpson's Paradox Matches are matches in which the winner has won fewer points (below the red line)"),
                                 plotOutput('sp'), 
                                 width = 6,
                                 height = 600),
                              box(htmlOutput("spTable"), width = 6,height = 600)))
        )
    )
))